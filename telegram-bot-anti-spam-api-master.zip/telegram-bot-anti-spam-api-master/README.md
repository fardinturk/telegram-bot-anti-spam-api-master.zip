# telegram-bot-anti-spam-api
anti spam bot php full
help : email "amirhh233@gmail.com" telegram id "https://t.me/amirhossein2o17" id bot (report) "https://t.me/pm_rs_bot"

